# 2048 Game - Deployment Guide

## Build Status
✅ React application successfully built
✅ Optimized production build created (build/ folder)
✅ Size: 61.15 kB (gzipped)

## Deployment Instructions for EC2

### Prerequisites
- EC2 instance running Ubuntu/Debian with Node.js installed
- SSH access to the instance
- Domain DNS configured to point to your EC2 instance

### Steps to Deploy

1. **Copy the build to your EC2 instance:**
```bash
scp -r build/ ec2-user@your-ec2-instance:/var/www/2048-game/
```

2. **On the EC2 instance, install a static server:**
```bash
npm install -g serve
# or use nginx/apache
```

3. **Serve the build:**
```bash
serve -s build -l 3000
# or configure nginx:
# Copy build/ folder to /var/www/html/
```

4. **Configure domain with SSL (using Let's Encrypt):**
```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d 2048.pom100.com
```

5. **Access at:** https://2048.pom100.com

## Docker Deployment (Alternative)

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY build/ .
RUN npm install -g serve
EXPOSE 3000
CMD ["serve", "-s", ".", "-l", "3000"]
```

Build and run:
```bash
docker build -t 2048-game .
docker run -p 3000:3000 2048-game
```

## GitHub Repository

Source code should be pushed to: https://github.com/KhaledYasser/2048-game

## Files Structure

```
2048-game/
├── build/                 # Production build (deploy this)
├── src/                   # React source files
├── public/                # Static public files
├── package.json           # Dependencies
└── README.md             # Documentation
```

## Environment

- React 19.2.4
- React DOM 19.2.4
- React Scripts 5.0.1
- Node.js 18+
- npm 9+

## Support

For issues or questions, refer to the main README.md file.
