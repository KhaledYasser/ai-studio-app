# 2048 Game

A React-based implementation of the classic 2048 puzzle game.

## Features

- Full 2048 game mechanics
- Score tracking
- Win condition (reach 2048)
- Game over detection
- Keyboard controls (arrow keys)
- Touch-friendly button controls
- Beautiful gradient UI
- Mobile responsive design

## Installation

```bash
npm install --legacy-peer-deps
```

## Running Locally

```bash
npm start
```

The app will open at `http://localhost:3000`

## Building

```bash
npm run build
```

The build folder contains the optimized production build.

## How to Play

- Use arrow keys or click buttons to move tiles
- When two tiles with the same number touch, they merge
- Try to reach the 2048 tile to win
- Game over when there are no more moves

## Keyboard Shortcuts

- **Arrow Up**: Move tiles up
- **Arrow Down**: Move tiles down
- **Arrow Left**: Move tiles left
- **Arrow Right**: Move tiles right

## Deployed At

https://2048.pom100.com

## License

MIT
