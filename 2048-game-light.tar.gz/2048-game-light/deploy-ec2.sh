#!/bin/bash

# 2048 Game Deployment Script for EC2
# Run this on your EC2 instance to deploy the game

set -e

echo "🚀 Starting 2048 Game Deployment..."

# Update system
echo "📦 Updating system packages..."
sudo apt-get update
sudo apt-get upgrade -y

# Install Node.js if not already installed
if ! command -v node &> /dev/null; then
    echo "📥 Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Install nginx if not already installed
if ! command -v nginx &> /dev/null; then
    echo "📥 Installing Nginx..."
    sudo apt-get install -y nginx
fi

# Create application directory
echo "📁 Creating application directory..."
sudo mkdir -p /var/www/2048-game
sudo chown -R $USER:$USER /var/www/2048-game

# Copy build files
echo "📋 Copying application files..."
cp -r build/* /var/www/2048-game/

# Copy nginx configuration
echo "🔧 Configuring Nginx..."
sudo cp nginx.conf /etc/nginx/sites-available/2048-game
sudo ln -sf /etc/nginx/sites-available/2048-game /etc/nginx/sites-enabled/2048-game
sudo rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
echo "✅ Testing Nginx configuration..."
sudo nginx -t

# Install SSL certificate (Let's Encrypt)
echo "🔐 Setting up SSL Certificate..."
if ! command -v certbot &> /dev/null; then
    sudo apt-get install -y certbot python3-certbot-nginx
fi

# Create certificate (you may need to adjust this)
sudo certbot certonly --nginx -d 2048.pom100.com --agree-tos --no-eff-email -m admin@pom100.com || true

# Restart nginx
echo "🔄 Restarting Nginx..."
sudo systemctl restart nginx
sudo systemctl enable nginx

# Install serve globally for backup static serving
echo "📥 Installing serve..."
sudo npm install -g serve

# Create systemd service (optional, for running Node app)
echo "⚙️  Creating systemd service..."
sudo cp 2048-game.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable 2048-game
# Uncomment below if you want to run Node.js directly instead of Nginx
# sudo systemctl start 2048-game

# Set permissions
echo "🔐 Setting permissions..."
sudo chown -R www-data:www-data /var/www/2048-game

# Display status
echo ""
echo "✅ Deployment Complete!"
echo ""
echo "📊 Status:"
echo "   • Nginx: $(sudo systemctl is-active nginx)"
echo "   • URL: https://2048.pom100.com"
echo ""
echo "🔗 Testing connection..."
sleep 2
curl -I https://2048.pom100.com 2>/dev/null | head -n 1

echo ""
echo "✨ Your 2048 game is live!"
